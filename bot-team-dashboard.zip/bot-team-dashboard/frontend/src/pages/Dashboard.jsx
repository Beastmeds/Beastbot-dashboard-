import React, {useState, useEffect} from 'react'
import axios from 'axios'

export default function Dashboard({token, role, onLogout}){
  const [logs, setLogs] = useState([]);
  const [message, setMessage] = useState('');
  const [channel, setChannel] = useState('discord');

  useEffect(()=>{ fetchLogs(); }, []);

  async function fetchLogs(){
    try{
      const res = await axios.get('http://localhost:4000/api/logs', { headers: { Authorization: 'Bearer '+token }});
      setLogs(res.data.logs || []);
    }catch(e){
      console.error(e);
    }
  }

  async function send(){
    try{
      const res = await axios.post('http://localhost:4000/api/send', { channel, message }, { headers: { Authorization: 'Bearer '+token }});
      alert('Sent: '+JSON.stringify(res.data));
      setMessage('');
    }catch(e){
      alert('Send failed: '+(e.response?.data?.error || e.message));
    }
  }

  async function restart(){
    try{
      const res = await axios.post('http://localhost:4000/api/restart', {}, { headers: { Authorization: 'Bearer '+token }});
      alert('Restarted: '+JSON.stringify(res.data));
    }catch(e){
      alert('Restart failed: '+(e.response?.data?.error || e.message));
    }
  }

  return (
    <div style={{padding:20}}>
      <h2>Dashboard</h2>
      <div>Role: <strong>{role}</strong></div>
      <button onClick={onLogout}>Logout</button>

      <hr />
      <h3>Senden</h3>
      <select value={channel} onChange={e=>setChannel(e.target.value)}>
        <option value="discord">Discord</option>
        <option value="whatsapp">WhatsApp</option>
      </select>
      <br />
      <textarea value={message} onChange={e=>setMessage(e.target.value)} rows={4} cols={50} />
      <br />
      <button onClick={send}>Send Message</button>

      <hr />
      <h3>Bot Aktionen</h3>
      <button onClick={restart}>Restart Bot</button>

      <hr />
      <h3>Logs</h3>
      <button onClick={fetchLogs}>Refresh Logs</button>
      <ul>
        {logs.map(l=> <li key={l.ts}>{new Date(l.ts).toLocaleString()}: {l.text}</li>)}
      </ul>
    </div>
  )
}
