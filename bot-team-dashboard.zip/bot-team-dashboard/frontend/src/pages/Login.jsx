import React, {useState} from 'react'
import axios from 'axios'

export default function Login({onLogin}){
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');
  async function submit(e){
    e.preventDefault();
    try{
      const res = await axios.post('http://localhost:4000/api/login', { email });
      onLogin(res.data.token, res.data.role);
    }catch(err){
      setError('Login failed');
    }
  }
  return (
    <div style={{padding:20}}>
      <h2>Login (demo)</h2>
      <form onSubmit={submit}>
        <input value={email} onChange={e=>setEmail(e.target.value)} placeholder="email (owner@example.com)" />
        <button type="submit">Login</button>
      </form>
      {error && <div style={{color:'red'}}>{error}</div>}
      <p>Beispiel-Accounts: owner@example.com, admin@example.com, mod@example.com, team@example.com</p>
    </div>
  )
}
