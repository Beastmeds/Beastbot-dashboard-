import React, {useState} from 'react'
import Login from './pages/Login'
import Dashboard from './pages/Dashboard'

export default function App(){
  const [token, setToken] = useState(localStorage.getItem('token') || null);
  const [role, setRole] = useState(localStorage.getItem('role') || null);

  if(!token){
    return <Login onLogin={(t, r)=>{ setToken(t); setRole(r); localStorage.setItem('token', t); localStorage.setItem('role', r); }} />
  }
  return <Dashboard token={token} role={role} onLogout={()=>{ localStorage.removeItem('token'); localStorage.removeItem('role'); setToken(null); setRole(null); }} />
}
