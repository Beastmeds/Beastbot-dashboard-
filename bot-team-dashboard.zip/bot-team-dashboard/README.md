# Bot Team Dashboard

Dieses Repository enthält ein vorkonfiguriertes Git-Projekt für eine Team-Webseite zur Steuerung deines WhatsApp- und Discord-Bots.

**Enthalten**
- Frontend: React (Vite) + Tailwind (schnell startklar)
- Backend: Node.js + Express mit Beispiel-API-Endpunkten (`/api/send`, `/api/restart`, `/api/logs`)
- Auth: Platzhalter für Firebase Auth / JWT (Beispiel mit JWT)
- Role-based access control (Beispiel: owner/admin/mod/team)

## Schnellstart (lokal)

### Backend
1. `cd backend`
2. `cp .env.example .env` -> `.env` anpassen
3. `npm install`
4. `npm run dev`

### Frontend
1. `cd frontend`
2. `npm install`
3. `npm run dev`
4. Öffne die angezeigte Vite-URL (z. B. http://localhost:5173)

## Deployment
- Frontend kann auf GitHub Pages / Vercel / Netlify deployt werden.
- Backend kann auf Render / Railway / Heroku / Firebase Cloud Functions deployt werden.

## Hinweise
- Dies ist eine Beispiel-Referenz. Für Produktion solltest du:
  - HTTPS & sichere JWT-Keys verwenden
  - echte Auth (z. B. Firebase Auth) integrieren
  - Rate limiting, logging & monitoring hinzufügen

Viel Erfolg — passe das Projekt an deine Bot-Logik an!
